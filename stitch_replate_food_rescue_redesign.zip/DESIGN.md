---
name: Civic Vitality
colors:
  surface: '#f6fbf5'
  surface-dim: '#d7dbd6'
  surface-bright: '#f6fbf5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f5f0'
  surface-container: '#ebefea'
  surface-container-high: '#e5e9e4'
  surface-container-highest: '#dfe4df'
  on-surface: '#181d1a'
  on-surface-variant: '#404942'
  inverse-surface: '#2c322e'
  inverse-on-surface: '#edf2ed'
  outline: '#707971'
  outline-variant: '#bfc9bf'
  surface-tint: '#296a46'
  primary: '#004527'
  on-primary: '#ffffff'
  primary-container: '#1b5e3b'
  on-primary-container: '#92d5a9'
  inverse-primary: '#92d5a9'
  secondary: '#a23e18'
  on-secondary: '#ffffff'
  secondary-container: '#fe8357'
  on-secondary-container: '#6f2000'
  tertiary: '#353e38'
  on-tertiary: '#ffffff'
  tertiary-container: '#4c554e'
  on-tertiary-container: '#c0c9c0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#aef2c4'
  primary-fixed-dim: '#92d5a9'
  on-primary-fixed: '#002110'
  on-primary-fixed-variant: '#085230'
  secondary-fixed: '#ffdbcf'
  secondary-fixed-dim: '#ffb59c'
  on-secondary-fixed: '#390c00'
  on-secondary-fixed-variant: '#822801'
  tertiary-fixed: '#dce5dc'
  tertiary-fixed-dim: '#c0c9c0'
  on-tertiary-fixed: '#151d18'
  on-tertiary-fixed-variant: '#404942'
  background: '#f6fbf5'
  on-background: '#181d1a'
  surface-variant: '#dfe4df'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  metric-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  metric-display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 2.5rem
  space-3xl: 3rem
  space-4xl: 4rem
---

## Brand & Style

This design system establishes a warm, grounded, and operationally rigorous design language built for real-world municipal logistics and community care. It rejects both cold, clinical enterprise SaaS abstractions and delicate editorial styling in favor of an empathetic, civic-infrastructure aesthetic.

The visual tone reflects reliability, vitality, and quiet urgency. Interfaces must serve four distinct personas across high-stress, time-sensitive environments:
- **Commercial Donors** needing friction-free inventory handoffs during peak operational closing shifts.
- **NGO Coordinators** managing intake capacity, distribution schedules, and dietary allocations.
- **Drivers** on the road needing instantaneous glanceability, large touch surfaces, and unmistakable status hierarchies.
- **System Dispatchers & Admins** operating multi-hub routing, cold-chain compliance, and systemic metric tracking.

The design movement balances **Modern Civic Utility** with **Organic Tactility**: tactile warm neutral planes, architectural hairline dividers, deep slate-ink typography with humanist warmth, and focused, earthy botanical and terracotta accents that drive immediate action without alarmist visual noise.

## Colors

The palette establishes an organic, grounded clarity rooted in civic responsibility and nourishment.

### Color Tokens & Roles
- **Canvas Base (`#FBF9F5`):** A warm parchment backdrop that reduces eye fatigue across extended dispatch and warehouse shifts.
- **Surface Flat (`#FFFFFF`):** High-clarity white for primary cards, active table rows, and modular input clusters.
- **Surface Raised & Subdued (`#F4EFEA`):** Earthy warm gray-buff used for table headers, inactive segments, and secondary structural panels.
- **Border Structural (`#E5DFD7`):** Hairline boundary defining visual containment without relying on blurred shadows.
- **Border Strong (`#C5BCB0`):** Interactive element boundaries, divider lines, and focused states.
- **Primary Ink (`#1E2320`):** Deep, vegetable-ink slate providing AAA accessible contrast against warm grounds.
- **Secondary Ink (`#58615A`):** Neutral botanical slate for secondary labels, units, and non-critical timestamps.
- **Brand Forest (`#1B5E3B`):** Deep botanical green conveying safety, renewal, and verified status (`#14472C` on hover/active).
- **Brand Terracotta (`#C85A32`):** Sunbaked clay accent commanding immediate focus for perishable alerts, critical dispatch timers, and urgent collection windows (`#A84522` on hover).

### Semantic Tokens
- **Success (`#237844` / surface: `#EBF6EE`):** Completed drop-offs, temperature within safe limits, confirmed capacity.
- **Warning (`#D48806` / surface: `#FEF7E6`):** Approaching pickup deadlines, impending cold-chain limit.
- **Danger (`#CF1322` / surface: `#FDECEE`):** Expired items, rejected deliveries, vehicle breakdown.
- **Info (`#1677FF` / surface: `#EDF5FF`):** Route updates, system sync state, logistical metadata.

## Typography

Typography relies on **Plus Jakarta Sans** across all roles, providing a modern, humanist clarity with generous counters and sturdy stems that remain legible in warehouse glare and small mobile screens.

### Operational Rigor & Tabular Numerals
- All metric visualizations, dispatch lists, manifests, scale readouts (kg/lbs), and countdown clocks **must** apply `font-variant-numeric: tabular-nums lining-nums`. This prevents layout jitter during real-time telemetry updates.
- Metric values use the designated `metric-display` scale combined with a smaller, baseline-aligned `label-md` unit indicator.
- Section tags, badge labels, and inventory categorizations leverage `label-sm` with slight uppercase tracking to maintain authoritative scan efficiency.

## Layout & Spacing

The layout is anchored on a rigid 4px rhythmic scale (4, 8, 12, 16, 24, 32, 40, 48, 64px). 

### Layout Breakpoints & Behavior
- **Desktop (1200px+):** 12-column grid, 24px gutters (`gutter`), 32px canvas margins (`margin`). Split dispatch interfaces allocate a persistent 360px operational side panel and an 8-column data viewport.
- **Tablet (768px - 1199px):** 8-column fluid grid, 16px gutters (`gutter-sm`), 24px margins. Navigation drawers collapse to an action rail; secondary metadata stacks beneath primary logistics logs.
- **Mobile (<768px):** 4-column fluid layout with 16px gutters and margins (`margin-sm`). Touch targets maintain a minimum 48px tap height. Multi-column inventory tables compress into unified vertical manifest tiles.

## Elevation & Depth

This design system avoids heavy, blurred drop shadows. Depth is communicated through structural layering, border boundaries, and tonal contrast:

- **Level 0 (Canvas Base):** Ground color `#FBF9F5`. Houses global page navigation and grid canvas.
- **Level 1 (Flat Cards & Panels):** `#FFFFFF` surface bordered by a 1px solid `#E5DFD7` outline. Zero blur. This represents the default operational plane.
- **Level 2 (Interactive Cards & Grouped Manifests):** `#FFFFFF` surface with a 1px `#DCD4CA` outline and a micro-offset anchor shadow: `0px 2px 4px rgba(30, 35, 32, 0.04)`.
- **Level 3 (Flyouts, Drawers & Popovers):** `#FFFFFF` surface with a crisp border (`#D4CBC0`) and an ambient, low-spread dispersion: `0px 6px 16px rgba(30, 35, 32, 0.08)`.
- **Level 4 (Critical Modals & Emergency Overrides):** `#FFFFFF` with `0px 12px 32px rgba(30, 35, 32, 0.12)`, underpinned by an ink-tinted parchment backdrop scrim: `rgba(30, 35, 32, 0.45)`.

## Shapes

The shape system is restrained, utilitarian, and architecturally grounded. It explicitly avoids bubbly, oversaturated pill treatments for core utility containers, opting for crisp structure with soft, humanized tactile corners.

### Shape Hierarchy
- **Inputs, Buttons, Tags, and Badges:** `4px` corner radius. Provides sharp alignment inside tight inventory grids while softening corner strikes.
- **Cards, Table Containers, and Grouped Wells:** `8px` corner radius. Softens content perimeter while maintaining clear structural borders.
- **Modals, Floating Sheets, and Sticky Drawers:** `12px` corner radius. Reserved exclusively for large focal interfaces.
- **Avatar & Status Pips:** `9999px` (Full Circle) strictly reserved for driver profile avatars and inline operational status dots.

## Components

### Buttons
- **Primary:** Background `#1B5E3B`, text `#FFFFFF`, border none, radius `4px`, padding `10px 18px`. Hover: `#14472C`. Active: `#0F3621`. Focus: 2px offset with `#1B5E3B`.
- **Urgent / Accent:** Background `#C85A32`, text `#FFFFFF`. Hover: `#A84522`. Used strictly for time-sensitive rescue acceptance, panic escalations, or perishable flags.
- **Secondary / Neutral:** Background `#FFFFFF`, border 1px solid `#E5DFD7`, text `#1E2320`. Hover: `#F4EFEA`, border `#C5BCB0`.
- **Ghost:** Background transparent, text `#58615A`. Hover: `#F4EFEA`, text `#1E2320`.

### Chips & Badges
- Built with 4px border radius, uppercase or bold sentence case (`label-sm`).
- **Standard Logistic Tag:** Background `#F4EFEA`, border 1px solid `#E5DFD7`, text `#58615A`.
- **Perishable Alert Badge:** Background `#FDECEE`, border 1px solid `#F7B2B7`, text `#CF1322`.
- **Cold-Chain / Transit Badge:** Background `#EDF5FF`, border 1px solid `#ADC6FF`, text `#1677FF`.

### Lists & Manifest Tables
- Row height: 48px default, 56px for touch/mobile manifests.
- Alternating subtle rows are forbidden; rows remain `#FFFFFF` separated by hairline 1px `#E5DFD7` borders. Hover state activates `#FAF7F2`.
- Numeric data columns (weights in kg, cases, distance, expiration counters) must use right-alignment and tabular figures.

### Input Fields & Controls
- **Inputs:** 40px height (48px on mobile), `#FFFFFF` background, 1px `#E5DFD7` border, 4px corner radius. Focused state: 1px border `#1B5E3B` and an ambient 2px outer ring `rgba(27, 94, 59, 0.15)`.
- **Checkboxes & Radios:** 18px square/circle with 1.5px border `#C5BCB0`. Checked state: `#1B5E3B` fill with white indicator icon.

### Cards
- Standard rescue dispatch card: `#FFFFFF` fill, 1px `#E5DFD7` border, 8px radius, 16px internal padding.
- Status header: Left-hand 3px colored accent stripe (e.g., `#C85A32` for immediate pickup, `#1B5E3B` for en-route, `#58615A` for scheduled).

### Specialized Civic Logistical Components
- **Perishable Countdown Timer:** High-visibility pill housing a ticking tabular clock paired with a terracotta status pip (`#C85A32`).
- **Chain of Custody Hand-off Card:** Split dual-party sign-off tile with driver and kitchen manager identity verification stamps.
- **Weight & Tray Stepper:** High-contrast `+` / `-` increment buttons flanking a large tabular measurement box optimized for cold-storage gloved inputs.